import { Entity, Column, Tree, TreeChildren, TreeParent, OneToMany, ManyToOne, JoinColumn } from 'typeorm';
import { BaseEntity } from '../../database/base/base.entity';


@Entity('nodes')
export class TreeEntity extends BaseEntity {
  @Column({ type: 'text' })
  title: string;

  @OneToMany(() => TreeEntity, tree => tree.parent)
  children: TreeEntity[];

  @ManyToOne(() => TreeEntity, tree => tree.children)
  @JoinColumn({ name: 'parent_id' })
  parent: TreeEntity;
}

