import { Injectable } from "@nestjs/common";
import { DataSource } from "typeorm";
import { TreeEntity } from "./tree.entity";
import { Tree } from "../domain/tree.model";
import { TreeMapper } from "./tree.mapper";


@Injectable()
export class TreeRepository {
    constructor(private dataSource: DataSource) {}

    async getTreeAsRoot(id: string): Promise<Tree> {
        let treeRep = this.dataSource.getTreeRepository(TreeEntity);

        return treeRep.findTrees().then(trees => TreeMapper.toDomain(trees[0]));
    }
}


